
import React from "react";
import "./index.css";
import { MoveRight } from "lucide-react";

function Card({ title, description, buttonText }) {
  return (
    <div className="bg-white text-black rounded-2xl shadow-xl p-6">
      <h2 className="text-xl font-semibold mb-2">{title}</h2>
      <p className="text-sm mb-4">{description}</p>
      <button className="bg-blue-700 text-white py-2 px-4 rounded w-full">{buttonText}</button>
    </div>
  );
}

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-800 to-blue-400 text-white p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold mb-2">Napoli</h1>
        <p className="text-lg">لكل الخدمات الإلكترونية في مكان واحد</p>
      </header>

      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card title="شحن رصيد" description="خدمة شحن الرصيد لجميع الشبكات بسرعة وسهولة." buttonText="ابدأ الآن" />
        <Card title="دفع فواتير" description="دفع فواتير الكهرباء، المياه، الإنترنت والمزيد." buttonText="جرب الخدمة" />
        <Card title="خدمات أخرى" description="بطاقات رقمية، تحويلات مالية، والمزيد." buttonText="استعرض الكل" />
      </div>

      <div className="mt-12 text-center">
        <h3 className="text-2xl font-bold mb-4">سجّل دخولك لتجربة أفضل</h3>
        <div className="max-w-md mx-auto flex gap-2">
          <input placeholder="رقم الهاتف أو البريد الإلكتروني" className="flex-1 p-2 rounded text-black" />
          <button className="bg-white text-blue-700 hover:bg-gray-100 py-2 px-4 rounded flex items-center">
            دخول <MoveRight className="ml-2 w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
